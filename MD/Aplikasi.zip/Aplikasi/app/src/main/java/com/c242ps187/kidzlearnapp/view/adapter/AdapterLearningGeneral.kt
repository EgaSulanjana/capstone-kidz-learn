package com.c242ps187.kidzlearnapp.view.adapter

import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.c242ps187.kidzlearnapp.data.api.response.UrlsItem
import com.c242ps187.kidzlearnapp.databinding.ItemLearningBinding
import com.c242ps187.kidzlearnapp.utils.Utils.dpToPx
import java.io.IOException

class AdapterLearningGeneral: ListAdapter<UrlsItem, AdapterLearningGeneral.MyViewHolder>(DIFF_CALLBACK) {
    private var showName = true
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemLearningBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val event = getItem(position)
        holder.bind(event)
    }

    inner class MyViewHolder(private val binding: ItemLearningBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(urlsItem: UrlsItem){
            Glide.with(binding.root)
                .load(urlsItem.urlImages)
                .into(binding.ivAnimal)

            if(!this@AdapterLearningGeneral.showName){
                binding.tvAnimalName.layoutParams = binding.tvAnimalName.layoutParams.apply {
                    height = 1.dpToPx()
                }
            }else{
                binding.tvAnimalName.text = urlsItem.name
                binding.tvAnimalName.layoutParams = binding.tvAnimalName.layoutParams.apply {
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                }
            }

            itemView.setOnClickListener {
                mediaPlayer?.apply {
                    if (isPlaying) {
                        stop()
                        release()
                    }
                }
                mediaPlayer = MediaPlayer().apply {
                    try {
                        setDataSource(urlsItem.urlSuara)
                        prepareAsync()
                        setOnPreparedListener {
                            start()
                        }
                        setOnCompletionListener {
                            release()
                            mediaPlayer = null
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }
            }
        }

    }

    fun showName(isShow: Boolean) {
        showName = isShow
    }

    companion object{
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<UrlsItem>(){
            override fun areItemsTheSame(oldItem: UrlsItem, newItem: UrlsItem): Boolean {
                return oldItem == newItem
            }

            @SuppressLint("DiffUtilEquals")
            override fun areContentsTheSame(
                oldItem: UrlsItem,
                newItem: UrlsItem
            ): Boolean {
                return oldItem == newItem
            }

        }
    }
}