package com.c242ps187.kidzlearnapp.data.api.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

data class QuestionsWritingResponse(

	@field:SerializedName("data")
	val data: List<DataItem>,

	@field:SerializedName("status")
	val status: String
)

data class DataItem(

	@field:SerializedName("isLock")
	val isLock: Boolean,

	@field:SerializedName("question")
	val question: List<QuestionItem>,

	@field:SerializedName("levelNumber")
	val levelNumber: String,

	@field:SerializedName("id")
	val id: String
)

@Parcelize
data class QuestionItem(

	@field:SerializedName("answer")
	val answer: String,

	@field:SerializedName("urlGuide")
	val urlGuide: String,

	@field:SerializedName("urlImg")
	val urlImg: String,

	@field:SerializedName("id")
	val id: String
): Parcelable
