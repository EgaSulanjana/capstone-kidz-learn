package com.c242ps187.kidzlearnapp.view.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.ViewGroup.MarginLayoutParams
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.c242ps187.kidzlearnapp.data.api.response.DataItem
import com.c242ps187.kidzlearnapp.databinding.ItemLevelBinding
import com.c242ps187.kidzlearnapp.utils.Utils.QUESTIONS
import com.c242ps187.kidzlearnapp.utils.Utils.dpToPx
import com.c242ps187.kidzlearnapp.view.activity.WritingActivity

class AdapterLevelsWriting: ListAdapter<DataItem, AdapterLevelsWriting.MyViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemLevelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val column = (position % 3) + 1
        val layoutParams = holder.itemView.layoutParams as MarginLayoutParams

        if (column == 2) {
            layoutParams.topMargin = 48.dpToPx()

        } else {
            layoutParams.topMargin = 24.dpToPx()
            layoutParams.bottomMargin = 24.dpToPx()
        }

        holder.itemView.layoutParams = layoutParams
        holder.bind(getItem(position))
    }

    class MyViewHolder(private val binding: ItemLevelBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(levels: DataItem){
            binding.btnLevel.isEnabled = !levels.isLock
            binding.btnLevel.text = levels.levelNumber
            binding.btnLevel.setOnClickListener{
                val intent = Intent(itemView.context, WritingActivity::class.java)
                intent.putParcelableArrayListExtra(QUESTIONS, ArrayList(levels.question))
                startActivity(itemView.context, intent, null)
            }
        }
    }

    companion object{
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<DataItem>(){
            override fun areItemsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
                return oldItem == newItem
            }

            @SuppressLint("DiffUtilEquals")
            override fun areContentsTheSame(
                oldItem: DataItem,
                newItem: DataItem
            ): Boolean {
                return oldItem == newItem
            }

        }
    }
}