package com.c242ps187.kidzlearnapp.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.c242ps187.kidzlearnapp.data.api.ApiService
import com.c242ps187.kidzlearnapp.data.api.response.AuthResponse
import com.c242ps187.kidzlearnapp.data.api.response.DataItem
import com.c242ps187.kidzlearnapp.data.api.response.ErrorResponse
import com.c242ps187.kidzlearnapp.data.api.response.UrlsItem
import com.c242ps187.kidzlearnapp.data.model.UserModel
import com.c242ps187.kidzlearnapp.data.pref.UserPreference
import com.c242ps187.kidzlearnapp.data.result.Result
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.HttpException

class MyRepository(
    private val userPreference: UserPreference,
    private val apiService: ApiService,
) {
    fun register(username: String, email: String, password: String): LiveData<Result<AuthResponse>> = liveData  {
        emit(Result.Loading)
        try{
            val response = apiService.register(username, email, password)
            emit(Result.Success(response))
        }catch (e: HttpException){
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody.message
            emit(Result.Error(errorMessage))
        }
    }

    fun login(email: String, password: String): LiveData<Result<AuthResponse>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.login(email, password)
            emit(Result.Success(response))
        }catch (e: HttpException){
            val jsonInString = e.response()?.errorBody()?.string()
            val errorBody = Gson().fromJson(jsonInString, ErrorResponse::class.java)
            val errorMessage = errorBody.message
            emit(Result.Error(errorMessage))
        }
    }

    fun getLearningAnimals(): LiveData<Result<List<UrlsItem>>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.getLearningAnimals()
            emit(Result.Success(response.urls))

        }catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getLearningColors(): LiveData<Result<List<UrlsItem>>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.getLearningColors()
            emit(Result.Success(response.urls))

        }catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getLearningNumbers(): LiveData<Result<List<UrlsItem>>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.getLearningNumbers()
            emit(Result.Success(response.urls))

        }catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getLearningAlphabetsK(): LiveData<Result<List<UrlsItem>>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.getLearningAlphabetsK()
            emit(Result.Success(response.urls))

        }catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getLearningAlphabets(): LiveData<Result<List<UrlsItem>>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.getLearningAlphabets()
            emit(Result.Success(response.urls))

        }catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getQuestionsWriting(): LiveData<Result<List<DataItem>>> = liveData {
        emit(Result.Loading)
        try{
            val response = apiService.getQuestionsWriting()
            emit(Result.Success(response.data.sortedBy { it.levelNumber }))
        }catch (e: Exception){
            emit(Result.Error(e.message.toString()))
        }
    }

    fun validateAnswer(multipartBody: MultipartBody.Part, requestBody: RequestBody): LiveData<Result<String>> = liveData{
        emit(Result.Loading)
        try {
            val successResponse = apiService.validateAnswer(multipartBody, requestBody)
            emit(Result.Success(successResponse.predictedChar))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)
            emit(Result.Error(errorResponse.message))
        }
    }

    fun updateProgress(userId: String, exp: Int): LiveData<Result<String>> = liveData{
        emit(Result.Loading)
        try {
            val successResponse = apiService.updateProgress(userId, exp)
            emit(Result.Success(successResponse.message))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)
            emit(Result.Error(errorResponse.message))
        }
    }

    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    companion object {
        fun getInstance(
            userPreference: UserPreference,
            apiService: ApiService,
        ): MyRepository = MyRepository(userPreference, apiService)
    }
}