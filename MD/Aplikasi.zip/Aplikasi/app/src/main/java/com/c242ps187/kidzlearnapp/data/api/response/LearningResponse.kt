package com.c242ps187.kidzlearnapp.data.api.response

import com.google.gson.annotations.SerializedName

data class LearningResponse(

	@field:SerializedName("urls")
	val urls: List<UrlsItem>
)

data class UrlsItem(

	@field:SerializedName("name")
	val name: String,

	@field:SerializedName("urlImages")
	val urlImages: String,

	@field:SerializedName("urlSuara")
	val urlSuara: String
)
