package com.c242ps187.kidzlearnapp.data.model

data class Exercises(
    val title: String,
    val levels: List<Levels>
)

data class Levels(
    val levelNumber: String,
)
