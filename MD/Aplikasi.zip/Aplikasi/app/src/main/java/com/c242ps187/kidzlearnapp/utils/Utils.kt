package com.c242ps187.kidzlearnapp.utils

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.view.isVisible
import com.c242ps187.kidzlearnapp.view.activity.NavActivity

object Utils {
    const val EXERCISE = "exercise"
    const val LEARNING = "learning"
    const val PROFILE = "profile"
    const val WRITING = "writing"
    const val EXP = "exp"
    const val QUESTIONS = "questions"
    const val ALPHABETS = "Huruf Kecil"
    const val ALPHABETSK = "Huruf Kapital"
    const val ANIMALS = "Hewan"
    const val COLORS = "Warna"
    const val NUMBERS = "Angka"
    const val NAME = "name"
    const val PROGRESS = "progress"
    const val FRAGMENT_TARGET = "fragment_target"

    fun ProgressBar.showLoading(isShow: Boolean) {
        this.isVisible = isShow
    }

    fun Context.showToast(message: String){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    fun Context.back(value: String) {
        startActivity(Intent(this, NavActivity::class.java).putExtra(FRAGMENT_TARGET, value))
    }

    fun Int.dpToPx(): Int {
        val density = Resources.getSystem().displayMetrics.density
        return (this * density).toInt()
    }


}