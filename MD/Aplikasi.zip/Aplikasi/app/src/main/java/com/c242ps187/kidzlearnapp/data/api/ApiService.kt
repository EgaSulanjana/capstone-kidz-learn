package com.c242ps187.kidzlearnapp.data.api

import com.c242ps187.kidzlearnapp.data.api.response.AuthResponse
import com.c242ps187.kidzlearnapp.data.api.response.LearningResponse
import com.c242ps187.kidzlearnapp.data.api.response.QuestionsWritingResponse
import com.c242ps187.kidzlearnapp.data.api.response.ValidateResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {
    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("username") username: String,
        @Field("email") email: String,
        @Field("password") password: String,
    ): AuthResponse

    @FormUrlEncoded
    @POST("login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String,
    ): AuthResponse

    @FormUrlEncoded
    @POST("update-progress")
    suspend fun updateProgress(
        @Field("userId") userId: String,
        @Field("expGained") expGained: Int,
        @Field("levelGained") levelGainer:Int = 0
    ): AuthResponse

    @GET("animals")
    suspend fun getLearningAnimals(): LearningResponse

    @GET("colors")
    suspend fun getLearningColors(): LearningResponse

    @GET("letterAnimation")
    suspend fun getLearningNumbers(): LearningResponse

    @GET("alphabet")
    suspend fun getLearningAlphabets(): LearningResponse

    @GET("alphabetAnimation")
    suspend fun getLearningAlphabetsK(): LearningResponse

    @GET("questionWritting")
    suspend fun getQuestionsWriting(): QuestionsWritingResponse

    @Multipart
    @POST("predict")
    suspend fun validateAnswer(
        @Part image: MultipartBody.Part,
        @Part("is_letter") isLetter: RequestBody,
    ): ValidateResponse
}