package com.c242ps187.kidzlearnapp.data.api.response

import com.google.gson.annotations.SerializedName

data class ValidateResponse(

	@field:SerializedName("predicted_char")
	val predictedChar: String,

	@field:SerializedName("probabilities")
	val probabilities: List<Any>
)
