package com.c242ps187.kidzlearnapp.view.activity

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.c242ps187.kidzlearnapp.R
import com.c242ps187.kidzlearnapp.data.api.response.QuestionItem
import com.c242ps187.kidzlearnapp.databinding.ActivityWritingBinding
import com.c242ps187.kidzlearnapp.utils.Utils.EXP
import com.c242ps187.kidzlearnapp.utils.Utils.NAME
import com.c242ps187.kidzlearnapp.utils.Utils.PROGRESS
import com.c242ps187.kidzlearnapp.utils.Utils.QUESTIONS
import com.c242ps187.kidzlearnapp.utils.Utils.WRITING
import com.c242ps187.kidzlearnapp.view.viewmodel.MainViewModel
import com.c242ps187.kidzlearnapp.view.viewmodel.ViewModelFactory
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class WritingActivity : AppCompatActivity() {
    private lateinit var questions: ArrayList<QuestionItem>
    private lateinit var binding: ActivityWritingBinding
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var isCorrect = true
    private var isNotifSession = true
    private var exp = 0
    private var currentQuestionIndex = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWritingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        questions = intent.getParcelableArrayListExtra<QuestionItem>(QUESTIONS)!!

        binding.btnOk.setOnClickListener {
//            val bitmap = binding.canvasView.getBitmap()
//            val file = bitmapToFile(this, bitmap)
//            val requestFile = file.asRequestBody("image/png".toMediaType())
//            val requestImage = MultipartBody.Part.createFormData("image", file.name, requestFile)
//            val isLetter = "true".toRequestBody("text/plain".toMediaType())
//
//            viewModel.validateAnswer(requestImage, isLetter).observe(this) { result ->
//                when (result) {
//                    is com.c242ps187.kidzlearnapp.data.result.Result.Loading -> {}
//                    is com.c242ps187.kidzlearnapp.data.result.Result.Success -> {
//                        if (questions[currentQuestionIndex].answer == result.data) {
//                            isCorrect = true
//                        } else {
//                            isCorrect = false
//                        }
//                    }
//
//                    is com.c242ps187.kidzlearnapp.data.result.Result.Error -> {
//                        this.showToast(result.error)
//                    }
//                }
//            }
            if (isNotifSession) {
                showNotif(true)
                currentQuestionIndex++
                isNotifSession = false
            } else {
                if (currentQuestionIndex < questions.size) {
                    binding.canvasView.clearCanvas()
                    showNotif(false)
                    showQuestion()
                    isNotifSession = true
                } else {
                    showNotif(false)
                    val intent = Intent(this, SkorActivity::class.java)
                    intent.putExtra(EXP, exp)
                    startActivity(intent)
                    finish()
                }
            }

        }

        binding.btnBack.setOnClickListener {
            AlertDialog.Builder(this).apply {
                setTitle(getString(R.string.are_you_sure_want_to_leave))
                setMessage(getString(R.string.your_progress_will_not_be_saved))
                setPositiveButton(getString(R.string.yes)) { _, _ ->
                    startActivity(Intent(this@WritingActivity, LevelWritingActivity::class.java).putExtra(NAME, WRITING))
                    finish()
                }
                setNeutralButton(getString(R.string.cancel)) { _, _ ->

                }
                create()
                show()
            }
        }

        binding.btnDelete.setOnClickListener{
            binding.canvasView.clearCanvas()
        }
    }

    private fun showNotif(b:Boolean){
        if(b) {
            setupNotif()
            binding.tvNotif.visibility = View.VISIBLE
            binding.btnOk.text = getString(R.string.next)
        }else {
            binding.tvNotif.visibility = View.GONE
            binding.btnOk.text = getString(R.string.check)
        }
    }

    private fun setupNotif() {
        if(isCorrect) {
            binding.tvNotif.setBackgroundColor(getColor(R.color.correct_color))
            binding.tvNotif.text = getString(R.string.correct)
            exp += 10
            val mediaPlayer = MediaPlayer.create(this, R.raw.sfx_correct)
            mediaPlayer.start()
        }else{
            binding.tvNotif.setBackgroundColor(getColor(R.color.wrong_color))
            binding.tvNotif.text = getString(R.string.wrong)
            val mediaPlayer = MediaPlayer.create(this, R.raw.sfx_wrong)
            mediaPlayer.start()
        }
    }

    private fun showQuestion() {
        val question = questions[currentQuestionIndex]
        val progress = (currentQuestionIndex + 1) * 100
        val duration: Long = 1000

        binding.pbProgress.max = questions.size * 100

        ObjectAnimator.ofInt(binding.pbProgress, PROGRESS, progress)
            .setDuration(duration)
            .start()

        Glide.with(this)
            .load(question.urlImg)
            .into(binding.imageView)

        Glide.with(this)
            .asBitmap()
            .load(question.urlGuide)
            .override(600, 600)
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    if (!isFinishing && !isDestroyed) {
                        binding.canvasView.setGuidingLineBitmap(resource)
                    }
                }
                override fun onLoadCleared(placeholder: Drawable?) {
                    binding.canvasView.setGuidingLineBitmap(null)
                }
            })
    }

    private fun bitmapToFile(context: Context, bitmap: Bitmap): File {
        val file = File(context.cacheDir, "fileName")
        try {
            val outputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            outputStream.flush()
            outputStream.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return file
    }

   override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this@WritingActivity, LevelWritingActivity::class.java))
        finish()
   }
}