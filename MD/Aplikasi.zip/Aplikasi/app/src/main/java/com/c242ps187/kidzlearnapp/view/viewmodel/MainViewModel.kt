package com.c242ps187.kidzlearnapp.view.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.c242ps187.kidzlearnapp.data.model.UserModel
import com.c242ps187.kidzlearnapp.data.result.Result
import com.c242ps187.kidzlearnapp.repository.MyRepository
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import okhttp3.RequestBody

class MainViewModel(private val repository: MyRepository) : ViewModel() {

    fun register(username: String, email: String, password: String) = repository.register(username, email, password)

    fun login(email: String, password: String) = repository.login(email, password)

    fun saveSession(user: UserModel) {
        viewModelScope.launch {
            repository.saveSession(user)
        }
    }

    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun getLearningAlphabetsK() = repository.getLearningAlphabetsK()

    fun getLearningAlphabets() = repository.getLearningAlphabets()

    fun getLearningAnimals() = repository.getLearningAnimals()

    fun getLearningNumbers() = repository.getLearningNumbers()

    fun getLearningColors() = repository.getLearningColors()

    fun getQuestionsWriting() = repository.getQuestionsWriting()

    fun updateProgress(userId: String, exp: Int) = repository.updateProgress(userId, exp)

    fun validateAnswer(multipartBody: MultipartBody.Part, requestBody: RequestBody): LiveData<Result<String>> {
       return repository.validateAnswer(multipartBody, requestBody)
    }
}