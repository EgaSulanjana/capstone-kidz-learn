package com.c242ps187.kidzlearnapp.data.api.response

import com.google.gson.annotations.SerializedName

data class UpdateResponse(
	@field:SerializedName("message")
	val message: String,

	@field:SerializedName("exp")
	val exp: Int,

	@field:SerializedName("level")
	val level: Int
)
