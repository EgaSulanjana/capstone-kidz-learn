package com.c242ps187.kidzlearnapp.data.model

data class UserModel(
    val username: String,
    val email: String,
    val token: String,
    val exp: Int,
    val userId: String,
)
