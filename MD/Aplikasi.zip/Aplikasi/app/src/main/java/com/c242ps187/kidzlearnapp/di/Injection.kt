package com.c242ps187.kidzlearnapp.di

import android.content.Context
import com.c242ps187.kidzlearnapp.data.api.ApiConfig
import com.c242ps187.kidzlearnapp.data.pref.UserPreference
import com.c242ps187.kidzlearnapp.data.pref.dataStore
import com.c242ps187.kidzlearnapp.repository.MyRepository

object Injection {
    fun provideRepository(context: Context): MyRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        return MyRepository.getInstance(pref, apiService)
    }
}