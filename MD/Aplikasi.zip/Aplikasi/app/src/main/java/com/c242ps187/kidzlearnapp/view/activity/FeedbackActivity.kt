package com.c242ps187.kidzlearnapp.view.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.c242ps187.kidzlearnapp.R
import com.c242ps187.kidzlearnapp.databinding.ActivityFeedbackBinding
import com.c242ps187.kidzlearnapp.utils.Utils.PROFILE
import com.c242ps187.kidzlearnapp.utils.Utils.back
import com.c242ps187.kidzlearnapp.utils.Utils.showToast


class FeedbackActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFeedbackBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            this.back(PROFILE)
            finish()
        }

        binding.btnSend.setOnClickListener {
            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(getString(R.string.email_to)))
                putExtra(Intent.EXTRA_SUBJECT, getString(R.string.kidzlearn_feedback))
                putExtra(Intent.EXTRA_TEXT, binding.edtFeedback.text.toString())
            }

            if (emailIntent.resolveActivity(packageManager) != null) {
                startActivity(Intent.createChooser(emailIntent, getString(R.string.send_email)))
            } else {
                this.showToast(getString(R.string.no_email_apps))
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        this.back(PROFILE)
        finish()
    }
}