package com.c242ps187.kidzlearnapp.view.activity

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.c242ps187.kidzlearnapp.R
import com.c242ps187.kidzlearnapp.data.api.response.UrlsItem
import com.c242ps187.kidzlearnapp.data.result.Result
import com.c242ps187.kidzlearnapp.databinding.ActivityLearningBinding
import com.c242ps187.kidzlearnapp.utils.Utils.ALPHABETS
import com.c242ps187.kidzlearnapp.utils.Utils.ALPHABETSK
import com.c242ps187.kidzlearnapp.utils.Utils.ANIMALS
import com.c242ps187.kidzlearnapp.utils.Utils.COLORS
import com.c242ps187.kidzlearnapp.utils.Utils.LEARNING
import com.c242ps187.kidzlearnapp.utils.Utils.NAME
import com.c242ps187.kidzlearnapp.utils.Utils.NUMBERS
import com.c242ps187.kidzlearnapp.utils.Utils.back
import com.c242ps187.kidzlearnapp.utils.Utils.showLoading
import com.c242ps187.kidzlearnapp.utils.Utils.showToast
import com.c242ps187.kidzlearnapp.view.adapter.AdapterLearningGeneral
import com.c242ps187.kidzlearnapp.view.viewmodel.MainViewModel
import com.c242ps187.kidzlearnapp.view.viewmodel.ViewModelFactory

class LearningActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLearningBinding
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private var userChoosen = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLearningBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userChoosen = intent.getStringExtra(NAME) !!

        binding.tvTitle.text = userChoosen

        binding.btnBack.setOnClickListener {
            handleBack(userChoosen)
        }

        when (userChoosen){
            ANIMALS -> { getAnimals() }
            COLORS -> { getColors() }
            NUMBERS -> { getNumbers() }
            ALPHABETSK -> { getAlphabetsK() }
            ALPHABETS -> { getAlphabets() }
        }
    }

    private fun handleBack(userChoosen: String){
        if(userChoosen.equals(ALPHABETSK) || userChoosen.equals(ALPHABETS)){
            startActivity(Intent(this, SelectAlphabetTypeActivity::class.java))
            finish()
        } else {
            this.back(LEARNING)
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        handleBack(userChoosen)
    }

    private fun getAnimals(){
        viewModel.getLearningAnimals().observe(this){ result ->
           processingResult(true, result)
        }
    }

    private fun getAlphabetsK() {
        viewModel.getLearningAlphabetsK().observe(this){ result ->
            processingResult(false, result)
        }
    }

    private fun getAlphabets() {
        viewModel.getLearningAlphabets().observe(this){ result ->
            processingResult(false, result)
        }
    }

    private fun getNumbers() {
        viewModel.getLearningNumbers().observe(this){ result ->
            processingResult(true, result)
        }
    }

    private fun getColors() {
        viewModel.getLearningColors().observe(this){ result ->
            processingResult(true, result)
        }
    }

    private fun processingResult(showName:Boolean, result: Result<List<UrlsItem>>) {
        val adapter = AdapterLearningGeneral()
        adapter.showName(showName)
        when(result){
            is Result.Loading -> binding.pbLearning.showLoading(true)
            is Result.Success -> {
                binding.pbLearning.showLoading(false)
                adapter.submitList(result.data)
                binding.rvLearning.adapter = adapter
                binding.rvLearning.layoutManager = GridLayoutManager(this, 3)
                this.showToast(getString(R.string.fetch_data_success))
            }
            is Result.Error -> {
                binding.pbLearning.showLoading(false)
                this.showToast(result.error)
            }
        }
    }
}