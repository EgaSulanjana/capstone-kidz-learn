package com.c242ps187.kidzlearnapp.view.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.c242ps187.kidzlearnapp.databinding.ActivitySelectAlphabetTypeBinding
import com.c242ps187.kidzlearnapp.utils.Utils.ALPHABETS
import com.c242ps187.kidzlearnapp.utils.Utils.ALPHABETSK
import com.c242ps187.kidzlearnapp.utils.Utils.LEARNING
import com.c242ps187.kidzlearnapp.utils.Utils.NAME
import com.c242ps187.kidzlearnapp.utils.Utils.back

class SelectAlphabetTypeActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySelectAlphabetTypeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectAlphabetTypeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent = Intent(this, LearningActivity::class.java)

        binding.btn1.setOnClickListener{
            intent.putExtra(NAME, ALPHABETSK)
            startActivity(intent)
        }
        binding.btn2.setOnClickListener{
            intent.putExtra(NAME, ALPHABETS)
            startActivity(intent)
        }

        binding.btnBack.setOnClickListener {
            this.back(LEARNING)
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        this.back(LEARNING)
        finish()
    }
}