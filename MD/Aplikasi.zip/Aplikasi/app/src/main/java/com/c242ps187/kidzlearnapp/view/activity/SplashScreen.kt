package com.c242ps187.kidzlearnapp.view.activity

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.c242ps187.kidzlearnapp.databinding.ActivitySplashScreenBinding
import com.c242ps187.kidzlearnapp.utils.Utils.PROGRESS
import com.c242ps187.kidzlearnapp.view.viewmodel.MainViewModel
import com.c242ps187.kidzlearnapp.view.viewmodel.ViewModelFactory

@SuppressLint("CustomSplashScreen")
class SplashScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySplashScreenBinding
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val progress = 1000
        val duration: Long = 3000

        binding.pbSplashScreen.max = progress


        viewModel.getSession().observe(this) { user ->
            ObjectAnimator.ofInt(binding.pbSplashScreen, PROGRESS, progress)
                .setDuration(duration)
                .start()

            Handler(Looper.getMainLooper()).postDelayed({
                if (user.token.isEmpty()) {
                    startActivity(Intent(this@SplashScreen, LoginActivity::class.java))
                    finish()
                } else {
                    val intent = Intent(this@SplashScreen, NavActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }, duration)
        }
    }
}