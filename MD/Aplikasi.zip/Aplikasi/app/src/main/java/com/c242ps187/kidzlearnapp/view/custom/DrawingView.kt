package com.c242ps187.kidzlearnapp.view.custom

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class DrawingView(context: Context, attrs: AttributeSet) : View(context, attrs) {

    private var currentPath = Path()

    private val drawingPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 32f
    }
    private var guidingBitmap: Bitmap? = null

    private lateinit var drawingBitmap: Bitmap
    private lateinit var drawingCanvas: Canvas


    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        drawingBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawingCanvas = Canvas(drawingBitmap)
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        guidingBitmap?.let { bitmap ->
            val componentWidth = width
            val componentHeight = height

            val imageWidth = bitmap.width
            val imageHeight = bitmap.height

            val xCenter = (componentWidth - imageWidth) / 2f
            val yCenter = (componentHeight - imageHeight) / 2f

            canvas.drawBitmap(bitmap, xCenter, yCenter, null)
        }
        if (::drawingCanvas.isInitialized) {
            canvas.drawBitmap(drawingBitmap, 0f, 0f, null)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> currentPath.moveTo(event.x, event.y)
            MotionEvent.ACTION_MOVE -> {
                currentPath.lineTo(event.x, event.y)
                drawingCanvas.drawPath(currentPath, drawingPaint)
            }
            MotionEvent.ACTION_UP -> currentPath.reset()

        }
        invalidate()
        return true
    }

    fun setGuidingLineBitmap(newBitmap: Bitmap?) {
        guidingBitmap = newBitmap
        invalidate()
    }

    fun clearCanvas() {
        drawingCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        invalidate()
    }

    fun getBitmap(): Bitmap {
        return drawingBitmap.copy(Bitmap.Config.ARGB_8888, false)
    }
}