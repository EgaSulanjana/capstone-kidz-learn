package com.c242ps187.kidzlearnapp.view.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.c242ps187.kidzlearnapp.databinding.FragmentLearningBinding
import com.c242ps187.kidzlearnapp.utils.Utils.ANIMALS
import com.c242ps187.kidzlearnapp.utils.Utils.COLORS
import com.c242ps187.kidzlearnapp.utils.Utils.NAME
import com.c242ps187.kidzlearnapp.utils.Utils.NUMBERS
import com.c242ps187.kidzlearnapp.view.activity.LearningActivity
import com.c242ps187.kidzlearnapp.view.activity.SelectAlphabetTypeActivity


class LearningFragment : Fragment() {
    private lateinit var binding: FragmentLearningBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLearningBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val intent = Intent(requireContext(), LearningActivity::class.java)

        binding.btnAnimals.setOnClickListener{
            intent.putExtra(NAME, ANIMALS)
            startActivity(intent)
        }
        binding.btnWarna.setOnClickListener{
            intent.putExtra(NAME, COLORS)
            startActivity(intent)
        }
        binding.btnAngka.setOnClickListener{
            intent.putExtra(NAME, NUMBERS)
            startActivity(intent)
        }
        binding.btnAlphabet.setOnClickListener{
            val intentSelect = Intent(requireContext(), SelectAlphabetTypeActivity::class.java)
            startActivity(intentSelect)
        }
    }
}