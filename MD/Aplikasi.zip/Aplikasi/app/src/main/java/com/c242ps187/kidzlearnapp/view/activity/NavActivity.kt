package com.c242ps187.kidzlearnapp.view.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.c242ps187.kidzlearnapp.R
import com.c242ps187.kidzlearnapp.databinding.ActivityNavBinding
import com.c242ps187.kidzlearnapp.utils.Utils.EXERCISE
import com.c242ps187.kidzlearnapp.utils.Utils.FRAGMENT_TARGET
import com.c242ps187.kidzlearnapp.utils.Utils.LEARNING
import com.c242ps187.kidzlearnapp.utils.Utils.PROFILE
import com.google.android.material.bottomnavigation.BottomNavigationView

class NavActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNavBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityNavBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView
        navView.itemIconTintList = null

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment_activity_nav) as NavHostFragment
        val navController = navHostFragment.navController
        navView.setupWithNavController(navController)
        val targetFragment = intent.getStringExtra(FRAGMENT_TARGET)

        if (targetFragment != null) {
            when (targetFragment) {
                EXERCISE -> {
                    navView.selectedItemId = R.id.nav_exercise
                    navController.navigate(R.id.nav_exercise)
                }
                LEARNING -> {
                    navView.selectedItemId = R.id.nav_learning
                    navController.navigate(R.id.nav_learning)
                }
                PROFILE -> {
                    navView.selectedItemId = R.id.nav_profile
                    navController.navigate(R.id.nav_profile)
                }
            }
        }
    }
}