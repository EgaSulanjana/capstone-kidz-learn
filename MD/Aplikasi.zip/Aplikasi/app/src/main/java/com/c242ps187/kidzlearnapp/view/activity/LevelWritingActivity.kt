package com.c242ps187.kidzlearnapp.view.activity

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.c242ps187.kidzlearnapp.data.result.Result
import com.c242ps187.kidzlearnapp.databinding.ActivityLevelBinding
import com.c242ps187.kidzlearnapp.utils.Utils.EXERCISE
import com.c242ps187.kidzlearnapp.utils.Utils.back
import com.c242ps187.kidzlearnapp.utils.Utils.showToast
import com.c242ps187.kidzlearnapp.view.adapter.AdapterLevelsWriting
import com.c242ps187.kidzlearnapp.view.viewmodel.MainViewModel
import com.c242ps187.kidzlearnapp.view.viewmodel.ViewModelFactory

class LevelWritingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLevelBinding
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLevelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupLevelOfWriting()

        binding.btnBack.setOnClickListener {
            this.back(EXERCISE)
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        this.back(EXERCISE)
        finish()
    }

    private fun setupLevelOfWriting(){
        viewModel.getQuestionsWriting().observe(this){ result ->
            when(result){
                is Result.Loading -> {}
                is Result.Success -> {
                    val adapter = AdapterLevelsWriting()
                    binding.rvLevels.layoutManager = GridLayoutManager(this, 3)
                    binding.rvLevels.adapter = adapter
                    adapter.submitList(result.data)
                }
                is Result.Error -> {
                    this.showToast(result.error)
                }
            }
        }
    }
}