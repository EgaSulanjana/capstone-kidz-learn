package com.c242ps187.kidzlearnapp.view.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.c242ps187.kidzlearnapp.databinding.ActivityComingSoonBinding
import com.c242ps187.kidzlearnapp.utils.Utils.EXERCISE
import com.c242ps187.kidzlearnapp.utils.Utils.back

class ComingSoonActivity : AppCompatActivity() {
    private lateinit var binding: ActivityComingSoonBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityComingSoonBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            this.back(EXERCISE)
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        this.back(EXERCISE)
        finish()
    }
}