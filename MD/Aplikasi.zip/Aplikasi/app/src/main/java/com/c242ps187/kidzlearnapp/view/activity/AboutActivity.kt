package com.c242ps187.kidzlearnapp.view.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.c242ps187.kidzlearnapp.databinding.ActivityAboutBinding
import com.c242ps187.kidzlearnapp.utils.Utils.PROFILE
import com.c242ps187.kidzlearnapp.utils.Utils.back

class AboutActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            this.back(PROFILE)
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        this.back(PROFILE)
        finish()
    }

}